package HashTables;

public @interface MartinTest {
	
}
