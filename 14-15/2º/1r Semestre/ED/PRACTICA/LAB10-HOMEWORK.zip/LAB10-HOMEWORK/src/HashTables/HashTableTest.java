package HashTables;

import static org.junit.Assert.*;

import org.junit.Test;

public class HashTableTest {

	@Test
	public void fTest() {
		// Example from Martin. Re-do at home
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 0.5);
		assertEquals(2, a.f(7, 0));
		assertEquals(3, a.f(7, 1));
		assertEquals(4, a.f(7, 2));
		assertEquals(0, a.f(7, 3));
				
		// Example from Martin.Re-do at home
		HashTable<Integer> b = new HashTable<Integer>(5, HashTable.QUADRATIC_PROBING, 0.5);
		assertEquals(2, b.f(7, 0));
		assertEquals(3, b.f(7, 1));
		assertEquals(1, b.f(7, 2));
		assertEquals(1, b.f(7, 3));

		// Example from Martin.Re-do at home
		HashTable<Character> c = new HashTable<Character>(5, HashTable.LINEAR_PROBING, 0.5);
		assertEquals(0, c.f('A', 0));
		assertEquals(1, c.f('A', 1));
		assertEquals(2, c.f('A', 2));
		assertEquals(3, c.f('A', 3));
				
		// Example from Martin.Re-do at home
		HashTable<Character> d = new HashTable<Character>(5, HashTable.QUADRATIC_PROBING, 0.5);
		assertEquals(0, d.f('A', 0));
		assertEquals(1, d.f('A', 1));
		assertEquals(4, d.f('A', 2));
		assertEquals(4, d.f('A', 3));

		HashTable<Character> f = new HashTable<Character>(5, HashTable.LINEAR_PROBING, 0.5);
		System.out.println(f.toString());

	}
	
	@Test
	public void AddSearchTest() {
		// Creating a hashTable.
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 1.0);
		a.add(4);
		a.add(13);
		a.add(24);
		a.add(3);
			
		assertEquals("[0] (1) = 24 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		assertEquals(true, a.search(3));
		assertEquals(false, a.search(12));
	}
	

	@Test
	public void testInt() {
		// Creating a hashTable.
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 0.5);
		assertEquals(2, a.f(7, 0));
		assertEquals(3, a.f(7, 1));
		assertEquals(4, a.f(7, 2));
		assertEquals(0, a.f(7, 3));

		// Creating a hashTable.
		HashTable<Integer> b = new HashTable<Integer>(5, HashTable.QUADRATIC_PROBING, 0.5);

		assertEquals(2, b.f(7, 0));
		assertEquals(3, b.f(7, 1));
		assertEquals(1, b.f(7, 2));
		assertEquals(1, b.f(7, 3));

	}

	@Test
	public void testChar() {
		// Creating a hashTable.
		HashTable<Character> a = new HashTable<Character>(5, HashTable.LINEAR_PROBING, 0.5);

		assertEquals(0, a.f('A', 0));
		assertEquals(1, a.f('A', 1));
		assertEquals(2, a.f('A', 2));
		assertEquals(3, a.f('A', 3));

		// Creating a hashTable.
		HashTable<Character> b = new HashTable<Character>(5, HashTable.QUADRATIC_PROBING, 0.5);

		assertEquals(0, b.f('A', 0));
		assertEquals(1, b.f('A', 1));
		assertEquals(4, b.f('A', 2));
		assertEquals(4, b.f('A', 3));

	}

	@Test
	public void testAdd() {
		// Creating a hashTable.
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 1.0);
		a.add(4);
		a.add(13);
		a.add(24);
		a.add(3);

		assertEquals("[0] (1) = 24 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		assertEquals(true, a.search(3));
		assertEquals(false, a.search(12));

		// Creating a hashTable.
		HashTable<Integer> b = new HashTable<Integer>(5, HashTable.QUADRATIC_PROBING, 1.0);
		b.add(4);
		b.add(13);
		b.add(24);
		b.add(3);

		assertEquals("[0] (1) = 24 - [1] (0) = null - [2] (1) = 3 - [3] (1) = 13 - [4] (1) = 4 - ", b.toString());
		assertEquals(true, b.search(3));
		assertEquals(false, b.search(12));

	}

	@Test
	public void testRemove() {
		// Creating a hashTable.
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 1.0);
		
		//Adding some nodes.
		a.add(4);
		a.add(13);
		a.add(24);
		a.add(3);
		System.out.println(a.toString());
		
		//Removing one node.
		a.remove(24);
		
		//Checking that the remove method works.
		assertEquals(true, a.search(3));
		System.out.println(a.toString());
		assertEquals("[0] (2) = 24 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		
		//Adding one node.
		a.add(15);
		assertEquals(true, a.search(3));
		assertEquals("[0] (1) = 15 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());

	}
	
	@Test
	public void testPrimes() {
		
		//Checking for some primes
		assertTrue(HashTable.isPrime(0));
		assertTrue(HashTable.isPrime(1));
		assertTrue(HashTable.isPrime(3));
		assertTrue(HashTable.isPrime(5));
		assertTrue(HashTable.isPrime(7));
		assertTrue(HashTable.isPrime(199));
		assertTrue(HashTable.isPrime(-13));
		
		//Check the nextPrime
		assertEquals(5, HashTable.nextPrime(3));
		
		//Check the prevPrime
		assertEquals(5, HashTable.prevPrime(7));
		
		//Check the nextPrime
		assertEquals(211, HashTable.nextPrime(199));
		assertEquals(211, HashTable.nextPrime(200));
		
		//Check the prevPrime
		assertEquals(367, HashTable.prevPrime(373));
	}
}


