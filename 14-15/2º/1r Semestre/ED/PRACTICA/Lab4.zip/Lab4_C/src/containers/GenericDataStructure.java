package containers;

import java.util.LinkedList;

public class GenericDataStructure<T extends Comparable<T>>{
	private LinkedList<T> collection = new LinkedList<T>();
	
	public void add(T string) {
		collection.add(string);
	}
	
	public String toString() {
		return collection.toString();
	}
	
	public int compareTwoElements(int firstPos, int secondPos) {
		return collection.get(firstPos).compareTo(collection.get(secondPos));
	}

}
