package containers;

public class SuperContainer<T, K> {
	private Container<T> container;
	private K info;
	private int key;
	
	public SuperContainer(Container<T> container, K info, int key){
		setContainer(container);
		setInfo(info);
		setKey(key);
	}
	
	public Container<T> getContainer() {
		return container;
	}
	public void setContainer(Container<T> container) {
		this.container = container;
	}
	public K getInfo() {
		return info;
	}
	public void setInfo(K info) {
		this.info = info;
	}
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	
	public String toString() {
		return (container.toString()+", "+info.toString()+", "+key);
	}
	

}
