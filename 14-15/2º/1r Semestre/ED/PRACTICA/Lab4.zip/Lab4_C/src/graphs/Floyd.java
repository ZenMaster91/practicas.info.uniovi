package graphs;

import java.util.ArrayList;

public class Floyd {

	//TODO ALEX Y GUILLE ,Opt(do test)


	public static final int NOT_A_VERTEX = -1;
	public static final int N = 3;
	   
	private double A[][];//Cost matrix.
    private double P[][];//Pathway matrix.
    
    
	protected double[][] getA()
    {
        return A;
	}
	
	protected double[][] getP(){
		return P;
		
	}
	
	protected double[][] initsFloyd(){
		A = new double[N][N];
		P = new double[N][N];
		
		return null;
	}
	
	protected double[][] floyd(int An){
		
	}
	
	public String printFloydPath(T departure , T arrival){
		
	}
	
	
}
