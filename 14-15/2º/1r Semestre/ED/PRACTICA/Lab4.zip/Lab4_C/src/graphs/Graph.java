package graphs;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class Graph<T> {
	private ArrayList<GraphNode<T>> nodes;
	private boolean[][] edges;
	private double[][] weight;
	private int size;

	public final static int INDEX_NOT_FOUND = -1;

	// CONSTRUCTOR------------------------------------------------------------
	/**
	 * Constructor that creates a graph with n nodes. At the moment of creation,
	 * the nodes will be empty.
	 * 
	 * @param n
	 *            Number of nodes.
	 * @throws Exception
	 */
	public Graph(int n) {
		if (n > 0) {

			nodes = new ArrayList<GraphNode<T>>();

			edges = new boolean[n][n];
			weight = new double[n][n];
			size = 0;
		}
	}

	// GETTERS AND SETTERS----------------------------------------------------
	/**
	 * Returns the number of elements in the graph.
	 * 
	 * @return number of elements in the graph.
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Returns the adjacency matrix for the graph. The first element is the
	 * origin and the second one the destination. If the content of a cell is
	 * true, it means there's a connection.
	 * 
	 * @return Adjacency matrix for the graph.
	 */
	public boolean[][] getEdges() {
		return edges;
	}

	/**
	 * Returns the weight matrix for the graph.
	 * 
	 * @return Weight matrix of the graph.
	 */
	public double[][] getWeight() {
		return weight;
	}

	// METHODS ---------------------------------------------------------------
	/**
	 * Returns the index of an element. If the element is not in the graph, -1
	 * will be returned.
	 * 
	 * @param element
	 *            Object to be found in the graph.
	 * @return Index of the element.
	 */
	public int getNode(T element) {
		for (int i = 0; i < size; i++) {
			if (nodes.get(i).getElement().equals(element))
				return i;
		}

		return INDEX_NOT_FOUND;
	}

	/**
	 * Adds a new element to the graph.
	 * 
	 * @param element
	 * @throws Exception
	 */
	public void addNode(T element) throws Exception {
		for (GraphNode<T> node : nodes) {
			if (node.getElement().equals(element))
				throw new Exception("Element is already in the graph.");
		}

		nodes.add(new GraphNode<T>(element));
		this.size += 1;
	}

	/**
	 * Creates an edge between two existing nodes given the elements they
	 * contain.
	 * 
	 * @param origin
	 * @param dest
	 * @param weight
	 * @throws Exception
	 */
	public void addEdge(T origin, T dest, double weight) throws Exception {
		this.weight[getNode(origin)][getNode(dest)] = weight;
		edges[getNode(origin)][getNode(dest)] = true;
	}

	/**
	 * Returns true if there is an edge in a certain direction given the
	 * elements in the origin and destination node.
	 * 
	 * @param origin
	 * @param dest
	 * @return
	 * @throws Exception
	 */
	public boolean existsEdge(T origin, T dest) throws Exception {
		return edges[getNode(origin)][getNode(dest)];
	}

	// METHOD 3
	public String traverseGraphDF(T element) {
		for (GraphNode<T> node : nodes) {
			node.setVisited(false);
		}
		int v = getNode(element);
		return (DFPrint(v));
	}

	private String DFPrint(int v) {
		nodes.get(v).setVisited(true);
		String aux = (nodes.get(v).getElement().toString());
		for (int i = 0; i < size; i++) {
			if (edges[v][i] && !nodes.get(i).isVisited())
				aux += "-"+DFPrint(i);
		}

		return aux;
	}
	
	// METHOD 3
	
	public void removeNode(T element) throws Exception{
		for (int i = 0; i < size; i++) {
			if (nodes.get(i).getElement().equals(element)){
				nodes.remove(i);
				size=size-1;
			}
				
		}

		//return INDEX_NOT_FOUND;
	}
	
	public void removeEdge (T origin,T dest) throws Exception{
        /* Confirm both endpoints exist. */
        if (!nodes.contains(origin) || !nodes.contains(dest))
            throw new NoSuchElementException("Both nodes must be in the graph.");

        /* Remove the edges from both adjacency lists. */
        weight[getNode(origin)][getNode(dest)] = INDEX_NOT_FOUND;
        edges[getNode(origin)][getNode(dest)] = false;
	}
	
	public void print(){
		System.out.println(nodes);
	}
	
}
